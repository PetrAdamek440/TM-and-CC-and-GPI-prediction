# "linkovy obr." pro kap 5 Vysledky, TM, CC struktury i GPI omega misto:

import matplotlib.pyplot as plt
import matplotlib.text
import matplotlib.cm as cm
import numpy as np
import matplotlib.mlab as mlab
from matplotlib.artist import Artist

from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle

from matplotlib.patches import Circle

from matplotlib.text import Text
from matplotlib.image import AxesImage

import tkinter

## lidsky lokus
## popis: >hg38_dna range=chr19:17389648-17406217 5'pad=0 3'pad=0 strand=+
#lenbPdp = 16570
#TMs = [[705,774],[12101,12170]]
#CCs = [[816,924],[1780,1847],[2028,2089],[2393,2445],[12236,12383],[14371,14468],[14874,15007],[15558,15574]]
#GPI = 2463
#

## kureci lokus - kur domaci
## popis: >galGal6_dna range=chr28:3531163-3538110 5'pad=0 3'pad=0 strand=-
#lenbPdp = 6948
#TMs = [[1990,2059],[3303,3372]]
#CCs = [[2122,2314],[2387,2484],[2601,2671],[2741,2802],[3384,3597],[4366,4463],[4545,4678],[4760,4806]]
#GPI = 2817
#

## mysi lokus - mys domaci
## popis: >mm10_dna range=chr8:71519771-71538962 5'pad=0 3'pad=0 strand=-
#lenbPdp =  19192
#TMs = [[1619,1688],[13293,13362]]
#CCs = [[1712,1835],[2528,2604],[3137,3177],[4170,4204],[13428,13578],[16406,16503],[16991,17124],[17580,17626]]
#GPI = 4210
#

## luskoun ostrovni
## popis:
## >ref|NW_023435982.1|:679097-704212 Manis javanica isolate MJ74 unplaced genomic scaffold, YNU_ManJav_2.0 scaffold_88, whole genome shotgun sequence
lenbPdp = 17754
TMs = [[5864,5933],[15151,15220]]
CCs = [[5987,6080],[6935,7011],[7258,7319],[7581,7603],[15298,15439],[16489,16586],[16958,17091],[17551,17591]]
GPI = 7606

## kalon vabivy
## popis:
## >ref|NW_006429864.1|:923553-939337 Pteropus alecto unplaced genomic scaffold, ASM32557v1 scaffold160, whole genome shotgun sequence
#lenbPdp =  15785
#TMs = [[4047,4116],[10555,10624]]
#CCs = [[4140,4263],[5090,5166],[5375,5436],[5686,5717],[10693,10843],[11931,12021]]
#GPI = 5720

# pro TM - zacatek:

xsP = np.linspace(1,1,lenbPdp)
plt.figure(figsize=(lenbPdp/120,lenbPdp/4800))
plt.hlines(y=1,xmin=1,xmax=lenbPdp,color='black',linestyle='-',lw=15)

for iTMs in range(len(TMs)):

    plt.hlines(y=1,xmin=(TMs[iTMs][0]),xmax=(TMs[iTMs][1]),color='red',linestyle='-',lw=75)

plt.yticks([])
plt.xticks([])
'''
if ((listORFsP_pozice[irpP_c00_4fA][0])%3 == 0):
    frameP_ORFall_lin = 1
elif ((listORFsP_pozice[irpP_c00_4fA][0] + 1)%3 == 0):
    frameP_ORFall_lin = 3
elif ((listORFsP_pozice[irpP_c00_4fA][0] + 2)%3 == 0):
    frameP_ORFall_lin = 2
else:
    continue
'''
#plt.annotate(str(listORFsP_pozice[irpP_c00_4fA][0]),(listORFsP_pozice[irpP_c00_4fA][0],1),fontsize=16)
#plt.annotate(str(listORFsP_pozice[irpP_c00_4fA][1]),(listORFsP_pozice[irpP_c00_4fA][1],1),fontsize=16)
#plt.annotate(str(lenbP),(lenbP,1),fontsize=12) # pridan popisek delky vlakna na konec modre cary v obr.
#plt.annotate(str(1),(1,1),fontsize=12) #  pridan popisek zacatku vlakna na zacatek modre cary v obr. = 1. bp, (cislo bp.=1)
'''
plt.annotate('Fr.:'+str(frameP_ORFall_lin),((listORFsP_pozice[irpP_c00_4fA][0]+listORFsP_pozice[irpP_c00_4fA][1])/2,1),fontsize=16,color='green',verticalalignment='top')
'''
plt.savefig('/home/oem/Documents/DP_2021/vlastni_DP/5_Vysledky/obrazky/TM-linky/TM-linka.png')

#plt.show()
plt.close()#

# pro TM - konec.

# pro CC - zacatek:

xsP = np.linspace(1,1,lenbPdp)
plt.figure(figsize=(lenbPdp/120,lenbPdp/4800))
plt.hlines(y=1,xmin=1,xmax=lenbPdp,color='black',linestyle='-',lw=15)

for iCCs in range(len(CCs)):

    plt.hlines(y=1,xmin=(CCs[iCCs][0]),xmax=(CCs[iCCs][1]),color='blue',linestyle='-',lw=75)

plt.yticks([])
plt.xticks([])

plt.savefig('/home/oem/Documents/DP_2021/vlastni_DP/5_Vysledky/obrazky/CC-linky/CC-linka.png')

#plt.show()
plt.close()#

# pro CC - konec.

# pro GPI - zacatek:

xsP = np.linspace(1,1,lenbPdp)
plt.figure(figsize=(lenbPdp/120,lenbPdp/4800))
plt.hlines(y=1,xmin=1,xmax=lenbPdp,color='black',linestyle='-',lw=15)

xy = (GPI,1)

GPI_circle = plt.Circle(xy,radius=75,color='yellow')

#fig, ax = plt.subplots()
fig = plt.gcf()
ax = fig.gca()
ax.add_patch(GPI_circle)

plt.yticks([])
plt.xticks([])

plt.savefig('/home/oem/Documents/DP_2021/vlastni_DP/5_Vysledky/obrazky/GPI-misto/GPI-misto.png')

#plt.show()
plt.close()#

# pro GPI - konec.

# pro vse - (TM, CC i GPI) - zacatek:

xsP = np.linspace(1,1,lenbPdp)
plt.figure(figsize=(lenbPdp/120,lenbPdp/4800))
plt.hlines(y=1,xmin=1,xmax=lenbPdp,color='black',linestyle='-',lw=15)

for iTMs in range(len(TMs)):
    plt.hlines(y=1,xmin=(TMs[iTMs][0]),xmax=(TMs[iTMs][1]),color='red',linestyle='-',lw=75)

for iCCs in range(len(CCs)):
    plt.hlines(y=1,xmin=(CCs[iCCs][0]),xmax=(CCs[iCCs][1]),color='blue',linestyle='-',lw=75)

'''
xy = (GPI,1)
GPI_circle = plt.Circle(xy,radius=75,color='yellow')
#fig, ax = plt.subplots()
fig = plt.gcf()
ax = fig.gca()
ax.add_patch(GPI_circle)
'''

wth = 260 # tj. width
hht = 80 # tj. height
xy = (GPI-0.5*wth,1-0.5*hht)
GPI_rectangle = plt.Rectangle(xy,wth,hht,angle=0.0,color='yellow') # orange
fig = plt.gcf()
ax = fig.gca()
ax.add_patch(GPI_rectangle)

plt.yticks([])
plt.xticks([])

plt.savefig('/home/oem/Documents/DP_2021/vlastni_DP/5_Vysledky/obrazky/all-TMs,CCs,GPIrect.png')
#plt.show()
plt.close()#

# pro vse - (TM, CC i GPI) - konec.
