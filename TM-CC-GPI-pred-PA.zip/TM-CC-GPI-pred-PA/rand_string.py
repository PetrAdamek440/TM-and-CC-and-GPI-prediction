import time
t = time.time()

bases = ['AGCT']

string = []

limit = 16500

string_file = open("/home/oem/Documents/rand_string.txt","w+")

import random

for B in range(limit):
    B = random.choice(bases[0])
    string += B

inter = ''
string = inter.join(string)

string_file.write(str(string))
string_file.close()

elapsed = time.time() - t
print('Elapsed time (seconds): ',elapsed)

